// some help metrial:
// https://www.hackerrank.com/challenges/operator-overloading/forum
class CircularInt{
    
    private:
        int begin,end;
    
    public:
        int currnt;
        CircularInt::CircularInt(int b,int e){
            begin=b;
            end=e;
            currnt=begin;
        }
        CircularInt::CircularInt & operator +=(const int hour){
            int newtime=begin+hour;
            if(newtime < end)
                currnt=newtime;
            else{
                currnt = newtime % (end-begin); 
            }
        }
        CircularInt::CircularInt & operator ++{
            currnt+=1;
        }
        //do i need to do one for regular int and one for CircularInt?
        
        CircularInt::CircularInt & operator +(const CircularInt hour){
            this->currnt+=hour.currnt;
        }
        
        //how to change regular num to the class number
        // CircularInt::CircularInt & operator -{
        //     if(currnt==end)
        // }
            
    
};


//halp from ansar from hackerrank
// Matrix & operator + (const Matrix &y) {

//     for (int m=0; m<y.a.size(); ++m) {
//         for (int n=0; n<y.a[0].size(); ++n) {
//             this->a[m][n] = this->a[m][n] + y.a[m][n];
//         }
//     }

//     return *this;
// }