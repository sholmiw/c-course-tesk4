

class CircularInt{
    
    private:
        int begin,end;
    
    public:
        int currnt;
        CircularInt::CircularInt(int b,int e){};
        CircularInt::CircularInt & operator +=(const int hour){};
        CircularInt::CircularInt & operator ++{};
        //do i need to do one for regular int and one for CircularInt?
        
        CircularInt::CircularInt & operator +(const CircularInt hour){};

        //how to change regular num to the class number
        // CircularInt::CircularInt & operator -{
        //     if(currnt==end)
        // }
            
};
